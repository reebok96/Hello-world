/**
 * Created with IntelliJ IDEA.
 * User: student
 * Date: 22.09.15
 * Time: 15:38
 * To change this template use File | Settings | File Templates.
 */
public class Lab {
    public static void main(String args[]){
        Laba a=new Laba();
        a.Array();
        a.InitArray();
        a.minmax();
        a.copymas();
        a.Sort();
        a.summ();
        a.kol();
        a.otr();
        a.avg();
        a.otrezok();
    }
}
