import java.util.Arrays;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: student
 * Date: 22.09.15
 * Time: 15:39
 * To change this template use File | Settings | File Templates.
 */
public class Laba {
    int size;
    int mas[];
    int mascopy[];
    int sum=0;
    int kol24=0;
    int otriz=0;
    double sred=0;
    int a,b;
    int kolotrezok=0;
    Scanner c=new Scanner(System.in);
    void Array(){
        System.out.print("Размерность массива:  ");
        size=c.nextInt();
        mas=new int[size];
    }
    void InitArray(){

        for(int i=0;i<mas.length;i++){
            System.out.print(i + 1 + " = ");
            mas[i]=c.nextInt();
        }
        for(int x:mas){
            System.out.print(x +" ");
        }
    }
    void minmax(){
        java.util.Arrays.sort(mas);
        System.out.println();
        System.out.println("Минимальный элемент массива:  "+mas[0]);
        System.out.println("Максимальный элемент массива:  "+mas[size-1]);
    }
    void copymas(){
        //mascopy=new int[mas.length];
        mascopy= Arrays.copyOf(mas,mas.length);
        System.out.print("Скопированный массив: ");
        for(int x:mascopy){
            System.out.print(x+ " ");
        }
        System.out.println();
    }
    void Sort(){
        Arrays.sort(mas);
        System.out.print("Отсортированный массив: ");
        for(int x:mas){
            System.out.print(x+ " ");
        }
    }
    void summ(){
        System.out.println();
       for(int i=0;i<mas.length;i++){
           if(mas[i]>-1){
               sum+=mas[i];
           }
       }
        System.out.println("Сумма положительных элементов массива "+ sum);
    }
    void kol(){
        for(int i=0;i<mas.length;i++){
            if(mas[i]%2==0){
                kol24++;
            }
        }
        System.out.println("Количество четных элементов: "+ kol24);
    }
    void otr(){
        for(int i=0;i<mas.length;i++){
            if(mas[i]<0){
                otriz++;
            }
        }
        System.out.println("Количество отрицательных элементов: "+ otriz);
    }
    void avg(){
        int summarray=0;
        for(int i=0;i<mas.length;i++){
           summarray+=mas[i];
        }
        sred=(summarray/mas.length);
        System.out.println("Среднее значение " + sred);
    }
    void otrezok(){
        System.out.print("a = ");
        a=c.nextInt();
        System.out.println();
        System.out.print("b = ");
        b=c.nextInt();
        System.out.println();
        for(int i=0;i<mas.length;i++){
            if(a<=mas[i] && mas[i]<=b) {
                kolotrezok++;
            }
        }
        System.out.println("Количество элементов, принадлежащих отрезку от " + a +" до "+ b+ " = "+kolotrezok);


    }


}
